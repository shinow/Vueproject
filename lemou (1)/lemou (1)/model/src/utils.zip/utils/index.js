// 有其他需要引入的东西直接引入  导出就行 api接口也可以
import axios from './axios'
import api from './api'
export {axios,api}